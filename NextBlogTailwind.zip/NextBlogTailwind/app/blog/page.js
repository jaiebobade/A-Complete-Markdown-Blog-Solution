

import React from 'react';
import 'tailwindcss/tailwind.css';
//import { Button } from 'shadcn';
//import { Button } from "@/components/ui/button"
import { buttonVariants } from "@/components/ui/button"
import Link from 'next/link';
import fs from "fs";
import matter from 'gray-matter';


const dirContent = fs.readdirSync("content", "utf-8")
const blogs = dirContent.map(file=>{
  const fileContent = fs.readFileSync(`content/${file}`, "utf-8")
  const {data} = matter(fileContent)
  return data
})


// const blogs = [
//   {
//     title: 'First Blog',
//     description: 'This is the first blog description.',
//     slug: 'first-blog',
//     author: 'John Doe',
//     date: '2023-10-01',
//     image: 'https://images.pexels.com/photos/879109/pexels-photo-879109.jpeg?auto=compress&cs=tinysrgb&w=600'
//   },
//   {
//     title: 'Second Blog',
//     description: 'This is the second blog description.',
//     slug: 'second-blog',
//     author: 'Jane Doe',
//     date: '2023-10-02',
//     image: 'https://images.pexels.com/photos/574077/pexels-photo-574077.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
//   },
//   {
//     title: 'Third Blog',
//     description: 'This is the third blog description.',
//     slug: 'third-blog',
//     author: 'Tom Doe',
//     date: '2024-10-02',
//     image: 'https://images.pexels.com/photos/7213210/pexels-photo-7213210.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
//   },
//   // Add more blog objects as needed
// ];

const Blog = () => {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-4xl font-bold mb-8 text-center">
        Blog
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {blogs.map((blog, index) => (
          <div key={index} className="rounded-lg shadow-md overflow-hidden dark:border-2">
            <img src={blog.image} alt={blog.title} className="w-full h-64 object-cover" />
            <div className="p-4">
              <h2 className="text-xl font-bold mb-2">{blog.title}</h2>
              <p className="mb-4">{blog.description}</p>
              <p className="text-sm mb-4">
                <span>{blog.date}</span> | <span>{blog.author}</span>
              </p>
              {/* <Button className="m-2" variant="outline" href={`/blog/${blog.slug}`}>Read More</Button> */}


              <Link href={`/blogpost/${blog.slug}`} className={buttonVariants({ variant: "outline" })}>Click here</Link>

            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Blog;